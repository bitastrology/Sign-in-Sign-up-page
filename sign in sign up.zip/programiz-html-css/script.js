const signInForm = document.getElementById("signInForm");
const signUpForm = document.getElementById("signUpForm");

function toggleForms() {
  signInForm.classList.toggle("hidden");
  signUpForm.classList.toggle("hidden");
}

function togglePassword(id) {
  const input = document.getElementById(id);
  const toggleText = input.nextElementSibling;
  if (input.type === "password") {
    input.type = "text";
    toggleText.textContent = "Hide";
  } else {
    input.type = "password";
    toggleText.textContent = "Show";
  }
}

signInForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const email = document.getElementById("signInEmail").value;
  const password = document.getElementById("signInPassword").value;
  if (email && password) {
    alert("Signed in successfully!");
    signInForm.reset();
  }
});

signUpForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const name = document.getElementById("signUpName").value;
  const email = document.getElementById("signUpEmail").value;
  const password = document.getElementById("signUpPassword").value;
  const confirm = document.getElementById("confirmPassword").value;

  if (password !== confirm) {
    alert("Passwords do not match!");
    return;
  }

  if (name && email && password) {
    alert("Account created successfully!");
    signUpForm.reset();
    toggleForms();
  }
});
